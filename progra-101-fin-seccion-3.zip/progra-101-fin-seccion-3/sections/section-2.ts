let numberOfLines = 0;

export function printLineNumber() {
    numberOfLines++;
    console.log('Línea #', numberOfLines );
}

printLineNumber();
printLineNumber();
printLineNumber();
printLineNumber();

