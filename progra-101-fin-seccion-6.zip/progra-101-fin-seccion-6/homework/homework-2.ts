
export let kms = 10;
let miles = kms * 0.62;


console.log('10 Kilómetros es igual a millas:', miles );
