// Ciclo While
// let gasTank = 0;

// while ( gasTank > 0 ) {
//     console.log('Gasolina restante', gasTank );

//     gasTank--;
// }

// console.log('Ya no tiene gasolina');

// Ciclo Do While
export let gasTank = 0;

do {
    console.log('Gasolina restante', gasTank );

    gasTank--;

} while ( gasTank > 0 );


console.log('Ya no tiene gasolina');



