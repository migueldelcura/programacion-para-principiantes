# Juego de ahorcado
Ejercicio del curso de programación para principiantes - Juego de ahorcado en React

# Ejecutar:

1. Clonar o descargar el código

2. Ejecutar ``` npm install ```

3. Ejecutar ``` npm run dev ```

4. Abrir el ```localhost:3000``` o el url que muestre la consola
