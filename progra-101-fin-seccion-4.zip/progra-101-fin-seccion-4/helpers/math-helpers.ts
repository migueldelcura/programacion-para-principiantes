
export function addTwoNumbers( num1: number, num2: number ): number {
    return num1 + num2;
}

export function substractTwoNumbers( num1: number, num2: number ): number {
    return num1 - num2;
}

export function timesTwoNumbers( num1: number, num2: number ): number {
    return num1 * num2;
}

export function divideTwoNumbers( num1: number, num2: number ): number {
    return num1 / num2;
}
