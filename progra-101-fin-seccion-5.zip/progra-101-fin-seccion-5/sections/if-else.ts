
console.log('Inicio de programa');

export let isTired:boolean = false;

// if ( isTired ) {
//     console.log('Tomar café');    
// } else {
//     console.log('Tomar agua');    
// }

// if ( !isTired ) {
//     console.log('Tomar Agua')
// }

let grade:number = 35;

if ( grade >= 60 ) {
    console.log('El alumno aprueba la clase!');
} else if( grade > 50 ) {
    console.log('Por favor estudie más!')
} else {
    console.log('El alumno NO aprueba la clase');
}



console.log('Fin de programa');