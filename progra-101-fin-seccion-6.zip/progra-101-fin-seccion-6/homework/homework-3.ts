
export let base = 10;
let height = 5;

let area = (base * height) / 2;

console.log('área igual a:', area );
