

export let pounds = 150;

let kgs = pounds * 0.453592;

console.log('150 libras es igual a kgs: ', kgs );

