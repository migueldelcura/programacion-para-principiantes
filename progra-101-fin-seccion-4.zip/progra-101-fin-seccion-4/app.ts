


console.log('Hola Mundo');
